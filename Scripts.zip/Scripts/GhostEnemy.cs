
using UnityEngine;

public class GhostEnemy : MonoBehaviour
{
    public float speed = 10.0f;
    public float turnCooldown = 0.2f;
    public float returnPause = 0.1f;
    public bool IsDead = false;

    public Collider2D detectionRange;
    public Transform patrolAnchor;

    private Animator animator;
    private Rigidbody2D rb;
    private Player player;
    private Transform target;
    private Collider2D playerCollider;

    private float direction = -1;
    private float cooldownTimer = 0f;

    private bool wasChasing = false;
    private bool returningToAnchor = false;
    private bool waitingAtAnchor = false;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        player = FindAnyObjectByType<Player>();

        target = GameObject.FindGameObjectWithTag("Player").transform;
        playerCollider = target.GetComponent<Collider2D>();
    }

    bool IsPlayerInRange()
    {
        return detectionRange != null &&
               playerCollider != null &&
               detectionRange.bounds.Intersects(playerCollider.bounds);
    }

    void Update()
    {
        if (IsDead)
            return;

        if (cooldownTimer > 0)
            cooldownTimer -= Time.deltaTime;

        bool playerInRange = IsPlayerInRange();

        if (playerInRange)
        {
            wasChasing = true;
            returningToAnchor = false;
            waitingAtAnchor = false;
            CancelInvoke(nameof(ResumePatrol));

            Vector2 chaseDirection =
                ((Vector2)target.position - rb.position).normalized;

            rb.linearVelocity = chaseDirection * speed;

            if (chaseDirection.x != 0)
                FaceDirection(Mathf.Sign(chaseDirection.x));

            return;
        }

        // Return to the anchor only after a chase ends.
        if (wasChasing)
        {
            wasChasing = false;
            CancelInvoke(nameof(ResumePatrol));
            waitingAtAnchor = false;

            if (patrolAnchor != null)
                returningToAnchor = true;
        }

        // Return to the patrol anchor.
        if (returningToAnchor && patrolAnchor != null)
        {
            Vector2 anchorPosition = patrolAnchor.position;
            Vector2 toAnchor = anchorPosition - rb.position;

            if (toAnchor.magnitude > 0.1f)
            {
                rb.linearVelocity = toAnchor.normalized * speed;

                if (toAnchor.x != 0)
                    FaceDirection(Mathf.Sign(toAnchor.x));
            }
            else
            {
                rb.position = anchorPosition;
                rb.linearVelocity = Vector2.zero;

                returningToAnchor = false;
                waitingAtAnchor = true;

                Invoke(nameof(ResumePatrol), returnPause);
            }

            return;
        }

        // Wait briefly at the anchor.
        if (waitingAtAnchor)
        {
            rb.linearVelocity = Vector2.zero;
            return;
        }

        // Normal horizontal patrol.
        rb.linearVelocity = new Vector2(direction * speed, 0f);
        FaceDirection(direction);
    }

    void FaceDirection(float moveDirection)
    {
        if (moveDirection == 0)
            return;

        transform.localScale = new Vector3(
            -Mathf.Abs(transform.localScale.x) * moveDirection,
            transform.localScale.y,
            transform.localScale.z
        );
    }

    void ResumePatrol()
    {
        waitingAtAnchor = false;
        rb.linearVelocity = new Vector2(direction * speed, 0f);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (IsDead)
            return;

        if (other.CompareTag("Edge") &&
            cooldownTimer <= 0 &&
            !IsPlayerInRange() &&
            !returningToAnchor &&
            !waitingAtAnchor)
        {
            cooldownTimer = turnCooldown;
            direction *= -1;
        }

        if (other.CompareTag("Fireball"))
        {
            if (player != null)
                player.AddScore(100);

            Die();
        }
    }

    void Die()
    {
        if (IsDead)
            return;

        IsDead = true;
        CancelInvoke(nameof(ResumePatrol));

        rb.linearVelocity = Vector2.zero;
        rb.simulated = false;

        animator.SetBool("IsDead", true);
        Destroy(gameObject, 0.5f);
    }
}
