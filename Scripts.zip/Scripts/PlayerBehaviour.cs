using UnityEngine;
using System.Collections;

public class PlayerBehaviour : MonoBehaviour
{
    private Animator animator;
    private AudioSource audioSource;
    Rigidbody2D rigidbody;
    private Player player;
    public float speed = 10.0f;
    public float JumpForce = 100.0f;

    public bool isGrounded = false;
    public bool isWalking = false;
    public bool isDamaged = false;

    public AudioClip JumpSound;

    void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();
        audioSource = GetComponentInChildren<AudioSource>();
        animator = GetComponent<Animator>();
        player = GetComponent<Player>();
    }

    // Update is called once per frame
    void Update()
    {
        var horizontal = Input.GetAxis("Horizontal");
        var vertical = Input.GetAxis("Jump");

        isWalking = Mathf.Abs(horizontal) > 0.1f;
        
        animator.SetBool("isWalking", isWalking);
        animator.SetBool("isDamaged", isDamaged);
        animator.SetBool("isGrounded", isGrounded);
        

        

        var movement = new Vector2(horizontal * speed, rigidbody.linearVelocity.y);
        rigidbody.linearVelocity = movement;

        //change sprite direction

        // Change sprite direction and size
        float playerSize = 1.0f;

        

        if (player != null && player.hasFireFlower)
        {
            playerSize = 1.2f;
        }

        if (horizontal > 0)
        {
            transform.localScale = new Vector3(playerSize, playerSize, 1);
        }
        else if (horizontal < 0)
        {
            transform.localScale = new Vector3(-playerSize, playerSize, 1);
        }

        if ((vertical > 0) && isGrounded)
        {
            rigidbody.AddForce(Vector2.up * JumpForce);
            isGrounded = false;
            audioSource.PlayOneShot(JumpSound);
        }
        if (Input.GetButtonDown("Fire1") && player != null)
        {
            player.ShootFireball();
        }
    }
    void OnCollisionEnter2D(Collision2D other)
    { 
        if(other.gameObject.CompareTag("Ground")|| other.gameObject.CompareTag("Enemy"))
        {
            isGrounded = true;
        }
    }
   public IEnumerator DamageAnimation()
    {
        isDamaged = true;
        animator.SetBool("isDamaged", true);
        yield return new WaitForSeconds(0.5f);
        isDamaged = false;
        animator.SetBool("isDamaged", false);
    }
}

