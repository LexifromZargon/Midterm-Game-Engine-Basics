
using UnityEngine;
using TMPro;

public class LevelTimer : MonoBehaviour
{
    public float timeLimit = 120f;
    public TMP_Text timerText;
    public GameObject gameOverScreen;

    private float timeRemaining;
    private bool timerEnded;

    void Start()
    {
        timeRemaining = timeLimit;
        timerEnded = false;

        if (gameOverScreen != null)
            gameOverScreen.SetActive(false);
    }

    void Update()
    {
        if (timerEnded)
            return;

        timeRemaining -= Time.deltaTime;

        if (timeRemaining <= 0f)
        {
            timeRemaining = 0f;
            timerEnded = true;

            if (timerText != null)
                timerText.text = "00:00";

            if (gameOverScreen != null)
                gameOverScreen.SetActive(true);

            enabled = false;
            return;
        }

        if (timerText != null)
        {
            int minutes = Mathf.FloorToInt(timeRemaining / 60f);
            int seconds = Mathf.FloorToInt(timeRemaining % 60f);
            timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
        }
    }
}
