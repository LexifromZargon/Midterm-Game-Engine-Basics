using UnityEngine;
using System.Collections.Generic;
public class InventoryManager : MonoBehaviour
{
    private PlayerInventoryDisplay display;
    private Dictionary<PickUp.PickUpType, int> items = new Dictionary<PickUp.PickUpType, int>();
    void Start()
    {
        display = GetComponent<PlayerInventoryDisplay>();
        display.OnChangeInventory(items);
    }

    public void Add(PickUp pickup)
    {
        PickUp.PickUpType type = pickup.type;

        if(items.TryGetValue(type,out int oldTotal))
            items[type] = oldTotal +1;
        else
            items.Add(type,1);
        display.OnChangeInventory(items);
    }
}
