using UnityEngine;

public class Clouds : MonoBehaviour
{
    public float speed = 2.0f;

    float direction = 1;

    void Update()
    {
        transform.position += Vector3.right * direction * speed * Time.deltaTime;
    }

}