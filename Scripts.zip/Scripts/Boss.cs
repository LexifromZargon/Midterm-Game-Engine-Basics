
using UnityEngine;
using TMPro;
using System.Collections;

public class Boss : MonoBehaviour
{
    [Header("Health")]
    public int maxHealth = 10;
    public int currentHealth = 10;
    public TMP_Text healthText;
    public GameObject healthBar;
    public bool IsDead;

    [Header("Movement")]
    public float speed = 3f;
    public float chaseSpeed = 2f;
    public float maxSpeedBonus = 2f;
    public float turnCooldown = 0.2f;
    public Collider2D detectionRange;

    [Header("Projectile")]
    public GameObject fireballPrefab;
    public Transform firePoint;

    [Header("Ground Slam")]
    public float jumpForce = 12f;
    public Collider2D slamCollider;
    public float slamDamageDuration = 0.3f;
    public float groundWaitTimeout = 3f;

    [Header("Attacks")]
    public float minAttackInterval = 1.5f;
    public float maxAttackInterval = 3f;
    public float hurtStunTime = 0.7f;

    [Header("Victory")]
    public int scoreReward = 500;
    public GameObject levelComplete;

    private Rigidbody2D rb;
    private Animator animator;
    private Player player;
    private Transform target;
    private Collider2D playerCollider;

    private float direction = -1f;
    private float cooldownTimer;
    private float currentSpeed;
    private bool isBusy;
    private bool isGrounded;
    private bool landingDetected;
    private bool slamHitPlayer;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        player = FindAnyObjectByType<Player>();

        GameObject playerObject = GameObject.FindGameObjectWithTag("Player");

        if (playerObject != null)
        {
            target = playerObject.transform;
            playerCollider = target.GetComponent<Collider2D>();

            if (playerCollider == null)
                playerCollider = target.GetComponentInChildren<Collider2D>();
        }
        else
        {
            Debug.LogError("[Boss] No GameObject tagged Player was found.");
        }

        if (rb == null)
            Debug.LogError("[Boss] Rigidbody2D is missing.", this);

        maxHealth = Mathf.Max(1, maxHealth);
        currentHealth = maxHealth;
        IsDead = false;
        currentSpeed = speed;

        UpdateHealthDisplay();

        if (healthBar != null)
            healthBar.SetActive(false);

        if (slamCollider != null)
            slamCollider.enabled = false;

        if (levelComplete != null)
            levelComplete.SetActive(false);

        SetAnimation("IsWalking", true);
    }

    void Update()
    {
        if (IsDead || target == null || rb == null)
            return;

        if (cooldownTimer > 0f)
            cooldownTimer -= Time.deltaTime;

        UpdateSpeed();

        if (isBusy)
            return;

        if (IsPlayerInRange())
        {
            FacePlayer();
            MoveTowardPlayer();
            isBusy = true;
            StartCoroutine(AttackAfterDelay());
        }
        else
        {
            Patrol();
        }
    }

    void UpdateSpeed()
    {
        float healthPercent = (float)currentHealth / maxHealth;
        currentSpeed = speed + (1f - healthPercent) * maxSpeedBonus;
    }

    bool IsPlayerInRange()
    {
        return target != null &&
               playerCollider != null &&
               detectionRange != null &&
               detectionRange.bounds.Intersects(playerCollider.bounds);
    }

    void Patrol()
    {
        SetAnimation("IsWalking", true);

        rb.linearVelocity = new Vector2(
            direction * currentSpeed,
            rb.linearVelocity.y
        );

        FaceDirection(direction);
    }

    void MoveTowardPlayer()
    {
        float difference = target.position.x - transform.position.x;

        if (Mathf.Abs(difference) > 1.5f)
        {
            float moveDirection = Mathf.Sign(difference);

            rb.linearVelocity = new Vector2(
                moveDirection * (chaseSpeed + currentSpeed - speed),
                rb.linearVelocity.y
            );

            FaceDirection(moveDirection);
            SetAnimation("IsWalking", true);
        }
        else
        {
            rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
            SetAnimation("IsWalking", false);
        }
    }

    void FacePlayer()
    {
        if (target == null)
            return;

        float difference = target.position.x - transform.position.x;

        if (difference != 0f)
            FaceDirection(Mathf.Sign(difference));
    }

    void FaceDirection(float moveDirection)
    {
        if (moveDirection == 0f)
            return;

        Vector3 scale = transform.localScale;
        scale.x = Mathf.Abs(scale.x) * Mathf.Sign(moveDirection);
        transform.localScale = scale;
    }

    IEnumerator AttackAfterDelay()
    {
        float delay = Random.Range(
            minAttackInterval,
            Mathf.Max(minAttackInterval, maxAttackInterval)
        );

        float timer = 0f;

        while (timer < delay && !IsDead)
        {
            if (!IsPlayerInRange())
            {
                isBusy = false;
                yield break;
            }

            FacePlayer();
            MoveTowardPlayer();

            timer += Time.deltaTime;
            yield return null;
        }

        if (IsDead)
            yield break;

        if (!IsPlayerInRange())
        {
            isBusy = false;
            yield break;
        }

        // More likely to shoot as health decreases.
        float healthPercent = (float)currentHealth / maxHealth;
        float projectileChance = Mathf.Lerp(0.75f, 0.25f, healthPercent);
        float attackRoll = Random.value;

        if (attackRoll < projectileChance)
            yield return StartCoroutine(ShootFireball());
        else if (Random.value < 0.5f)
            yield return StartCoroutine(JumpAttack());
        else
            yield return StartCoroutine(GroundSlam());

        if (!IsDead)
            isBusy = false;
    }

    IEnumerator ShootFireball()
    {
        if (fireballPrefab == null || firePoint == null || target == null)
        {
            Debug.LogError("[Boss] Assign the projectile prefab and Fire Point.", this);
            yield break;
        }

        SetAnimation("IsWalking", false);
        rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
        FacePlayer();

        GameObject projectile = Instantiate(
            fireballPrefab,
            firePoint.position,
            Quaternion.identity
        );

        BossProjectile bossProjectile = projectile.GetComponent<BossProjectile>();

        if (bossProjectile == null)
            bossProjectile = projectile.GetComponentInChildren<BossProjectile>();

        if (bossProjectile == null)
        {
            Debug.LogError(
                "[Boss] The projectile prefab has no BossProjectile script.",
                projectile
            );

            Destroy(projectile);
            yield break;
        }

        float shootDirection = Mathf.Sign(target.position.x - transform.position.x);

        if (shootDirection == 0f)
            shootDirection = 1f;

        bossProjectile.Launch(shootDirection);

        yield return new WaitForSeconds(0.4f);
    }

    IEnumerator JumpAttack()
    {
        if (!isGrounded)
        {
            isBusy = false;
            yield break;
        }

        yield return StartCoroutine(JumpAndLand());
    }

    IEnumerator GroundSlam()
    {
        if (!isGrounded)
        {
            float timer = 0f;

            while (!isGrounded && timer < groundWaitTimeout && !IsDead)
            {
                timer += Time.deltaTime;
                yield return null;
            }
        }

        if (IsDead || !isGrounded)
        {
            isBusy = false;
            yield break;
        }

        yield return StartCoroutine(JumpAndLand());

        if (IsDead || !landingDetected)
        {
            isBusy = false;
            yield break;
        }

        rb.linearVelocity = new Vector2(0f, rb.linearVelocity.y);
        slamHitPlayer = false;

        if (slamCollider != null)
            slamCollider.enabled = true;
        else
            Debug.LogWarning("[Boss] Assign the Slam Collider in the Inspector.", this);

        yield return new WaitForSeconds(slamDamageDuration);

        if (slamCollider != null)
            slamCollider.enabled = false;

        SetAnimation("GroundSlam", false);
    }

    IEnumerator JumpAndLand()
    {
        landingDetected = false;
        isGrounded = false;

        float jumpDirection = target != null
            ? Mathf.Sign(target.position.x - transform.position.x)
            : direction;

        if (jumpDirection == 0f)
            jumpDirection = direction;

        FaceDirection(jumpDirection);
        SetAnimation("IsWalking", false);
        SetAnimation("Jump", true);

        rb.linearVelocity = new Vector2(
            jumpDirection * currentSpeed * 1.5f,
            jumpForce
        );

        float timer = 0f;

        while (!landingDetected && !IsDead && timer < groundWaitTimeout)
        {
            timer += Time.deltaTime;
            yield return null;
        }

        SetAnimation("Jump", false);
    }

    public void TakeBossFireballDamage()
    {
        TakeDamage();
    }

    public void TakeBossDamage()
    {
        TakeDamage();
    }

    void TakeDamage()
    {
        if (IsDead)
            return;

        if (healthBar != null)
            healthBar.SetActive(true);

        currentHealth = Mathf.Max(0, currentHealth - 1);
        UpdateHealthDisplay();
        UpdateSpeed();

        if (currentHealth <= 0)
        {
            Die();
            return;
        }

        StopAllCoroutines();
        isBusy = true;
        StartCoroutine(HitReaction());
    }

    IEnumerator HitReaction()
    {
        rb.linearVelocity = Vector2.zero;

        if (slamCollider != null)
            slamCollider.enabled = false;

        SetAnimation("IsWalking", false);
        SetAnimation("Jump", false);
        SetAnimation("GroundSlam", false);
        SetAnimation("Hurt", true);

        yield return new WaitForSeconds(hurtStunTime);

        if (IsDead)
            yield break;

        SetAnimation("Hurt", false);

        // Jump toward the player after taking damage.
        yield return StartCoroutine(JumpAndLand());

        if (!IsDead)
            isBusy = false;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        CheckGroundContact(collision);
    }

    void OnCollisionStay2D(Collision2D collision)
    {
        CheckGroundContact(collision);
    }

    void CheckGroundContact(Collision2D collision)
    {
        for (int i = 0; i < collision.contactCount; i++)
        {
            if (collision.GetContact(i).normal.y > 0.5f)
            {
                isGrounded = true;
                landingDetected = true;
                return;
            }
        }
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        isGrounded = false;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (IsDead)
            return;

        if (other.CompareTag("Edge") &&
            cooldownTimer <= 0f &&
            !IsPlayerInRange() &&
            !isBusy)
        {
            cooldownTimer = turnCooldown;
            direction *= -1f;
            FaceDirection(direction);
        }

        Fireball fireball = other.GetComponent<Fireball>();

        if (fireball == null)
            fireball = other.GetComponentInParent<Fireball>();

        if (fireball != null)
        {
            Destroy(fireball.gameObject);
            TakeBossFireballDamage();
            return;
        }

        if (slamCollider != null &&
            slamCollider.enabled &&
            other.CompareTag("Player") &&
            !slamHitPlayer)
        {
            Player hitPlayer = other.GetComponentInParent<Player>();

            if (hitPlayer != null)
            {
                slamHitPlayer = true;
                hitPlayer.TakeDamage(2);
            }
        }
    }

    void UpdateHealthDisplay()
    {
        if (healthText != null)
            healthText.text = currentHealth + " / " + maxHealth;
    }

    void SetAnimation(string parameter, bool value)
    {
        if (animator != null)
            animator.SetBool(parameter, value);
    }

    void Die()
    {
        if (IsDead)
            return;

        IsDead = true;
        isBusy = true;
        StopAllCoroutines();

        if (rb != null)
        {
            rb.linearVelocity = Vector2.zero;
            rb.simulated = false;
        }

        if (slamCollider != null)
            slamCollider.enabled = false;

        SetAnimation("IsWalking", false);
        SetAnimation("Hurt", false);
        SetAnimation("Jump", false);
        SetAnimation("GroundSlam", false);
        SetAnimation("IsDead", true);

        if (player != null)
        {
            player.AddScore(scoreReward);
            player.VictoryScreen();
        }

        if (levelComplete != null)
            levelComplete.SetActive(true);

        Destroy(gameObject, 1.5f);
    }
}
