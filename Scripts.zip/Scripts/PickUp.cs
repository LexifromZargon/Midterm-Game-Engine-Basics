using UnityEngine;

public class PickUp : MonoBehaviour
{
   public enum PickUpType { Coin, Flower, Heart}
    public PickUpType type;
}
