
using UnityEngine;
using TMPro;
using System.Collections.Generic;

public class PlayerInventoryDisplay : MonoBehaviour
{
    public TMP_Text inventoryText;

    public void OnChangeInventory(Dictionary<PickUp.PickUpType, int> items)
    {
        int coins = 0;
       

        if (items.ContainsKey(PickUp.PickUpType.Coin))
        {
            coins = items[PickUp.PickUpType.Coin];
            
        }

        inventoryText.text = coins.ToString();
       
    }
}
