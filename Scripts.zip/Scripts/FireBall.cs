
using UnityEngine;

public class Fireball : MonoBehaviour
{
    public float lifeTime = 1.0f;
    public float speed = 8.0f;

    private Rigidbody2D rb;
    private bool hasHit = false;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Start()
    {
        Destroy(gameObject, lifeTime);
    }

    public void Launch(float shootDirection, Vector3 playerScale)
    {
        float direction = Mathf.Sign(shootDirection);

        transform.localScale = new Vector3(
            -Mathf.Abs(playerScale.x) * direction,
            Mathf.Abs(playerScale.y),
            playerScale.z
        );

        if (rb != null)
            rb.linearVelocity = new Vector2(direction * speed, 0f);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (hasHit)
            return;

        if (other.CompareTag("Enemy") || other.CompareTag("Ground"))
        {
            hasHit = true;
            Destroy(gameObject);
        }
    }
}
