
using UnityEngine;

public class BettleEnemy : MonoBehaviour
{
    public bool AtEdge = false;
    public float speed = 10.0f;
    public float turnCooldown = 0.2f;
    public bool IsDead = false;

    private Animator animator;
    private Rigidbody2D rigidbody;
    private Player player;

    float direction = -1;

    void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        player = FindAnyObjectByType<Player>();
    }

    void Update()
    {
        if (IsDead)
        {
            animator.SetBool("IsDead", true);
            return;
        }

        var v = rigidbody.linearVelocity;
        rigidbody.linearVelocity = new Vector2(direction * speed, v.y);

        if (turnCooldown > 0)
        {
            turnCooldown -= Time.deltaTime;
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Edge") && turnCooldown <= 0)
        {
            AtEdge = true;
            turnCooldown = 0.2f;

            direction *= -1;

            transform.localScale = new Vector2(
                -transform.localScale.x,
                transform.localScale.y
            );

            AtEdge = false;
        }

        if (other.CompareTag("Fireball") && !IsDead)
        {
            IsDead = true;
            player.AddScore(100);
            Destroy(gameObject, 0.5f);
        }
    }
}
