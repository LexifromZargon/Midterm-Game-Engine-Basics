
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform player;

    public float followSpeed = 5f;
    public float zoom = 7f;
    public float verticalOffset = 1f;

    [Header("Starting Section")]
    public float minY = 3.5f;

    [Header("First Drop")]
    public float dropX = 50f;
    public float lowerMinY = 1.56f;

    [Header("Second Drop")]
    public float secondDropX = 100f;
    public float secondLowerMinY = -22.3f;

    [Header("Third Drop")]
    public float thirdDropX = 150f;
    public float thirdLowerMinY = -30f;

    private Camera cam;

    void Start()
    {
        cam = GetComponent<Camera>();

        if (cam != null)
            cam.orthographicSize = zoom;
    }

    void LateUpdate()
    {
        if (player == null) return;

        float currentMinY = minY;

        if (player.position.x >= dropX)
            currentMinY = lowerMinY;

        if (player.position.x >= secondDropX)
            currentMinY = secondLowerMinY;

        if (player.position.x >= thirdDropX)
            currentMinY = thirdLowerMinY;

        float targetY = Mathf.Max(
            player.position.y + verticalOffset,
            currentMinY
        );

        Vector3 targetPosition = new Vector3(
            player.position.x,
            targetY,
            transform.position.z
        );

        transform.position = Vector3.Lerp(
            transform.position,
            targetPosition,
            followSpeed * Time.deltaTime
        );
    }
}
