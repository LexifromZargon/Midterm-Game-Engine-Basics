
using UnityEngine;

public class BossProjectile : MonoBehaviour
{
    public float speed = 8f;
    public float lifeTime = 4f;

    private Rigidbody2D rb;
    private bool hasHit;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();

        if (rb == null)
            Debug.LogError(
                "BossProjectile needs a Rigidbody2D on the same GameObject.",
                this
            );
    }

    void Start()
    {
        Destroy(gameObject, lifeTime);
    }

    public void Launch(float direction)
    {
        if (rb == null)
            rb = GetComponent<Rigidbody2D>();

        if (rb == null)
        {
            Debug.LogError(
                "BossProjectile cannot launch: Rigidbody2D is missing from this GameObject.",
                this
            );
            return;
        }

        rb.gravityScale = 0f;
        rb.linearVelocity = new Vector2(
            Mathf.Sign(direction) * speed,
            0f
        );

        Vector3 scale = transform.localScale;
        scale.x = Mathf.Abs(scale.x) * Mathf.Sign(direction);
        transform.localScale = scale;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (hasHit)
            return;

        Player hitPlayer = other.GetComponentInParent<Player>();

        if (hitPlayer != null)
        {
            hasHit = true;
            hitPlayer.TakeDamage(1);
            Destroy(gameObject);
            return;
        }

        if (other.CompareTag("Ground"))
        {
            hasHit = true;
            Destroy(gameObject);
        }
    }
}
