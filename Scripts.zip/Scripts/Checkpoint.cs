
using UnityEngine;

public class Checkpoint : MonoBehaviour
{
    [Header("Checkpoint Objects")]
    public GameObject checkpointMarker;

    private bool activated = false;
    private AudioSource audioSource;
    public AudioClip Activated;
    private void Start()
    {
        audioSource = GetComponentInChildren<AudioSource>();
        // Hide the marker until the checkpoint is activated.
        if (checkpointMarker != null)
            checkpointMarker.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player") || activated)
            return;

        activated = true;


        activated = true;

        if (checkpointMarker != null)
            checkpointMarker.SetActive(true);

        Player player = other.GetComponentInParent<Player>();

        if (player != null)
            player.AddScore(50);

        if (audioSource != null && Activated != null)
            audioSource.PlayOneShot(Activated);

    }
}
