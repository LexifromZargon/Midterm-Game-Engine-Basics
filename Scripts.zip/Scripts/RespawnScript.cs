
using UnityEngine;

public class RespawnScript : MonoBehaviour
{
    private Vector3 checkpointPosition;

    void Start()
    {
        // Save the player's starting position as the default checkpoint.
        checkpointPosition = transform.position;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        // Check whether the player touched a checkpoint.
        if (other.CompareTag("Checkpoint"))
        {
            checkpointPosition = other.transform.position;

            Debug.Log("Checkpoint reached!");
        }
    }

    public void Respawn()
    {
        transform.position = checkpointPosition;
    }
}
