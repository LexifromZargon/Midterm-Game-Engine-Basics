﻿
using UnityEngine;
using TMPro;
using System.Collections;


public class Player : MonoBehaviour
{
    public PlayerBehaviour playerBehaviour;
    public TMP_Text heartsText;
    public GameObject levelComplete;
    public GameObject GameOver;
    public GameObject fireballPrefab;
    public Transform firePoint;
    public TMP_Text scoreText;
    public int score = 0;

    private InventoryManager inventoryManager;
    private AudioSource audioSource;
    private AudioSource backgroundAudio;
    private Animator animator;
    private RespawnScript respawnScript;

    public bool PlayerDead = false;
    private bool CanTakeDamage = true;
    public int lives = 3;
    public bool hasFireFlower = false;
    private Vector3 originalScale;
    private GameObject activeFireball;

    public AudioClip CoinSound;
    public AudioClip PlayerHurt;
    public AudioClip BeetleDeath;
    public AudioClip FlowerSound;
    public AudioClip HeartsSound;
    public AudioClip GameOverSound;
    public AudioClip Background;
    public AudioClip FireballSound;
    public AudioClip GhostDeath;
    public AudioClip VictorySound;


    //ai was used to find compiler errors like misspelling capitalization errors etc.

    void Start()
    {
        originalScale = transform.localScale;
        animator = GetComponent<Animator>();
        inventoryManager = GetComponent<InventoryManager>();
        audioSource = GetComponentInChildren<AudioSource>();
        playerBehaviour = GetComponent<PlayerBehaviour>();
        respawnScript = GetComponent<RespawnScript>();

        backgroundAudio = gameObject.AddComponent<AudioSource>();
        backgroundAudio.clip = Background;
        backgroundAudio.loop = true;
        backgroundAudio.volume = 0.2f;
        backgroundAudio.Play();

        UpdateHearts();
    }
    
    public void UpdateHearts()
    {
        heartsText.text = "";
        for (int i = 0; i < lives; i++)
        {
            heartsText.text += "♥ ";
        }
    }
    public void UpdateScore()
    {
        scoreText.text = "Score: " + score;
    }

    public void AddScore(int points)
    {
        score += points;
        if (score < 0)
        {
            score = 0;
        }
        UpdateScore();
    }

    public void PlayBeetleDeathSound()
    {
        if (audioSource != null && BeetleDeath != null)
            audioSource.PlayOneShot(BeetleDeath);
    }
    public void ActivateFireFlower()
    {
        hasFireFlower = true;
        transform.localScale = new Vector3(
            originalScale.x * 1.2f,
            originalScale.y * 1.2f,
            originalScale.z
        );
    }

    public void ShootFireball()
    {
        if (!hasFireFlower || fireballPrefab == null || firePoint == null)
            return;

        // Do not shoot while another fireball exists.
        if (activeFireball != null)
            return;

        // Spawn an independent projectile, NOT a child of the player.
        activeFireball = Instantiate(
            fireballPrefab,
            firePoint.position,
            Quaternion.identity
        );

        activeFireball.SetActive(true);

        Fireball projectile = activeFireball.GetComponent<Fireball>();

        if (projectile != null)
        {
            float direction = Mathf.Sign(transform.localScale.x);
            projectile.Launch(direction, transform.localScale);
            audioSource.PlayOneShot(FireballSound);
        }
        else
        {
            Debug.LogError("The Fireball prefab has no Fireball script!");
            Destroy(activeFireball);
            activeFireball = null;
        }
    }
    public void VictoryScreen()
    {
        if (PlayerDead)
            return;

        PlayerDead = true;

        if (levelComplete != null)
            levelComplete.SetActive(true);

        if (backgroundAudio != null)
            backgroundAudio.Stop();
            audioSource.PlayOneShot(VictorySound);

        if (animator != null)
            animator.SetBool("PlayerDead", false);

        if (playerBehaviour != null)
            playerBehaviour.enabled = false;
    }
    public void GameOverScreen()
    {
        if (PlayerDead)
            return;
        PlayerDead = true;

        GameOver.SetActive(true);

        backgroundAudio.Stop();
        audioSource.PlayOneShot(GameOverSound);
        animator.SetBool("PlayerDead", true); 
        // Play the damage animation
        playerBehaviour.StartCoroutine(playerBehaviour.DamageAnimation());

        // Stop the player from moving
        playerBehaviour.enabled = false;
        StartCoroutine(RespawnAfterDelay());
    }

    public void TimeUp()
    {
        GameOverScreen();
    }
    IEnumerator RespawnAfterDelay()
    {
        Debug.Log("Respawn coroutine started!");
        yield return new WaitForSeconds(3.3f);
        Debug.Log("Respawn after x sec!");
        // Move the player to the last checkpoint.
        respawnScript.Respawn();

        // Reset the player's physics.
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        rb.linearVelocity = Vector2.zero;

        // Restore the player's lives.
        lives = 3;
        UpdateHearts();

        // Reset death state and animation.
        animator.SetBool("PlayerDead", false);
        playerBehaviour.isDamaged = false;
        PlayerDead = false;
        CanTakeDamage = true;

        // Resume the game.
        GameOver.SetActive(false);
        playerBehaviour.enabled = true;
        backgroundAudio.Play();
    }
    public void RemoveFireFlower()
    {
        hasFireFlower = false;
        transform.localScale = originalScale;
    }
    void OnTriggerEnter2D(Collider2D hit)
    {
        if (hit.CompareTag("InstantDeath"))
        {
            lives = 0;
            RemoveFireFlower();
            UpdateHearts();
            animator.SetBool("PlayerDead", true);
            GameOverScreen();

            return;
        }

        if (hit.CompareTag("PickUp"))
        {
            PickUp item = hit.GetComponent<PickUp>();

            inventoryManager.Add(item);
            Destroy(hit.gameObject);

        switch (item.type)
            {
                case PickUp.PickUpType.Coin:
                        audioSource.PlayOneShot(CoinSound);
                    AddScore(5);
                    break;

                case PickUp.PickUpType.Flower:
                    ActivateFireFlower();
                    audioSource.PlayOneShot(FlowerSound);
                    AddScore(10);

                    break;

                case PickUp.PickUpType.Heart:
                    lives += 1;
                    UpdateHearts();
                    audioSource.PlayOneShot(HeartsSound);
                    AddScore(30);
                    break;
            }
  
        }

    }

    void OnCollisionEnter2D(Collision2D hit)
    {
        if (hit.collider.CompareTag("BossWeakpoint"))
{
    Boss boss = hit.collider.GetComponentInParent<Boss>();

    if (boss != null && !boss.IsDead)
    {
        boss.TakeBossDamage();
        audioSource.PlayOneShot(BeetleDeath);
        AddScore(10);
        return;
    }
}
        if (hit.collider.CompareTag("BeetleWeakpoint"))
        {
            BettleEnemy enemy = hit.collider.transform.parent.GetComponent<BettleEnemy>();

            enemy.IsDead = true;

            audioSource.PlayOneShot(BeetleDeath);

            Destroy(hit.collider.transform.parent.gameObject, 0.5f);
            AddScore(100);

            return;
        }
        if (hit.collider.CompareTag("GhostWeakpoint"))
        {
            GhostEnemy ghost =
                hit.collider.transform.parent.GetComponent<GhostEnemy>();

            if (ghost != null && !ghost.IsDead)
            {
                ghost.IsDead = true;

                audioSource.PlayOneShot(GhostDeath);

                Destroy(hit.collider.transform.parent.gameObject, 0.5f);
                AddScore(100);

                return;
            }
        }

            if (hit.collider.CompareTag("Enemy") && CanTakeDamage)
        {
            StartCoroutine(TakeDamage());
        }
    }
    
    
        public IEnumerator TakeDamage()
    {
        CanTakeDamage = false;
        if (hasFireFlower)
        {
            RemoveFireFlower();
            audioSource.PlayOneShot(PlayerHurt);
           
            yield return new WaitForSeconds(1.0f);
            CanTakeDamage = true;
            yield break;
            
        }
        lives -= 1;
        AddScore(-30);
        audioSource.PlayOneShot(PlayerHurt);
        UpdateHearts();

        // Play damage animation
        playerBehaviour.StartCoroutine(playerBehaviour.DamageAnimation());

        if (lives <= 0)
        {
            GameOverScreen();
            animator.SetBool("PlayerDead", true);
            AddScore(-100);
        }
       
        yield return new WaitForSeconds(1.0f);

        CanTakeDamage = true;
    }
    public void TakeDamage(int damage)
    {
        StartCoroutine(TakeDamageWithAmount(damage));
    }

    private IEnumerator TakeDamageWithAmount(int damage)
    {
        CanTakeDamage = false;

        if (hasFireFlower)
        {
            RemoveFireFlower();
            audioSource.PlayOneShot(PlayerHurt);

            yield return new WaitForSeconds(1.0f);
            CanTakeDamage = true;
            yield break;
        }

        lives -= damage;
        AddScore(-30 * damage);
        audioSource.PlayOneShot(PlayerHurt);
        UpdateHearts();

        playerBehaviour.StartCoroutine(playerBehaviour.DamageAnimation());

        if (lives <= 0)
        {
            GameOverScreen();
            animator.SetBool("PlayerDead", true);
            AddScore(-100);
        }

        yield return new WaitForSeconds(1.0f);
        CanTakeDamage = true;
    }
}
